<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Nieprawidłowe dane opcjonalne</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>c987f2a7-7a7f-4402-9d9d-39f010a59d7a</testSuiteGuid>
   <testCaseLink>
      <guid>aa78a7a0-63c6-42d8-9509-7c8a749a6ced</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Nieprawidłowe dane opcjonalne</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
