<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Nieprawidłowy kod lotniska</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>9e1e81ea-9a70-430a-8905-3cb3ac76a63f</testSuiteGuid>
   <testCaseLink>
      <guid>633d4d8f-34c8-46d0-9819-4936999a62fc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Nieprawidłowy kod lotniska</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
