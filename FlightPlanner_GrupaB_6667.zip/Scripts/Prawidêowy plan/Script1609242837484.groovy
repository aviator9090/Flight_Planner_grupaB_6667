import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

'Otwarcie stony FlightPlanner'
WebUI.openBrowser(rawUrl = GlobalVariable.url)

'Wpisanie prawidłowego kodu ICAO lotniska początkowego'
WebUI.setText(findTestObject('Object Repository/Prawidłowy plan/Page_Flight Planner - Flight Plan Database/input_Destination_fromICAO'), 
    GlobalVariable.icao_wro)

'Wpisanie prawidłowego kodu ICAO lotniska docelowego'
WebUI.setText(findTestObject('Object Repository/Prawidłowy plan/Page_Flight Planner - Flight Plan Database/input__toICAO'), 
    GlobalVariable.icao_epwa)

'Wpisanie szybkości wznoszenia samolotu'
WebUI.setText(findTestObject('Object Repository/Prawidłowy plan/Page_Flight Planner - Flight Plan Database/input_ftmin_ascentRate'), 
    GlobalVariable.ascent_rate)

'Wpisanie wysokości przelotowej'
WebUI.setText(findTestObject('Object Repository/Prawidłowy plan/Page_Flight Planner - Flight Plan Database/input_ft_cruiseAlt'), 
    GlobalVariable.cruise_alt)

'Wpisanie szybkości obniżania samolotu'
WebUI.setText(findTestObject('Object Repository/Prawidłowy plan/Page_Flight Planner - Flight Plan Database/input_ftmin_descentRate'), 
    GlobalVariable.descent_rate)

'Wpisanie prędkości wznoszenia'
WebUI.setText(findTestObject('Object Repository/Prawidłowy plan/Page_Flight Planner - Flight Plan Database/input_kts_ascentSpeed'), 
    GlobalVariable.ascent_speed)

'Wpisanie prędkośći przelotowej'
WebUI.setText(findTestObject('Object Repository/Prawidłowy plan/Page_Flight Planner - Flight Plan Database/input_kts_cruiseSpeed'), 
    GlobalVariable.cruise_speed)

'Wpisanie prędkości obniżania'
WebUI.setText(findTestObject('Object Repository/Prawidłowy plan/Page_Flight Planner - Flight Plan Database/input_kts_descentSpeed'), 
    GlobalVariable.descent_speed)

'Zatwierdzenie planu lotu'
WebUI.click(findTestObject('Object Repository/Prawidłowy plan/Page_Flight Planner - Flight Plan Database/div_Go'))

'Zamknięcie przeglądarki'
WebUI.closeBrowser()

