package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object icao_wro
     
    /**
     * <p></p>
     */
    public static Object icao_epwa
     
    /**
     * <p></p>
     */
    public static Object ascent_rate
     
    /**
     * <p></p>
     */
    public static Object cruise_alt
     
    /**
     * <p></p>
     */
    public static Object descent_rate
     
    /**
     * <p></p>
     */
    public static Object ascent_speed
     
    /**
     * <p></p>
     */
    public static Object cruise_speed
     
    /**
     * <p></p>
     */
    public static Object descent_speed
     
    /**
     * <p></p>
     */
    public static Object url
     
    /**
     * <p></p>
     */
    public static Object icao_epwa_bad
     
    /**
     * <p></p>
     */
    public static Object ascent_rate_bad
     
    /**
     * <p></p>
     */
    public static Object cruise_alt_bad
     
    /**
     * <p></p>
     */
    public static Object descent_rate_bad
     
    /**
     * <p></p>
     */
    public static Object ascent_speed_bad
     
    /**
     * <p></p>
     */
    public static Object cruise_speed_bad
     
    /**
     * <p></p>
     */
    public static Object descent_speed_bad
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            icao_wro = selectedVariables['icao_wro']
            icao_epwa = selectedVariables['icao_epwa']
            ascent_rate = selectedVariables['ascent_rate']
            cruise_alt = selectedVariables['cruise_alt']
            descent_rate = selectedVariables['descent_rate']
            ascent_speed = selectedVariables['ascent_speed']
            cruise_speed = selectedVariables['cruise_speed']
            descent_speed = selectedVariables['descent_speed']
            url = selectedVariables['url']
            icao_epwa_bad = selectedVariables['icao_epwa_bad']
            ascent_rate_bad = selectedVariables['ascent_rate_bad']
            cruise_alt_bad = selectedVariables['cruise_alt_bad']
            descent_rate_bad = selectedVariables['descent_rate_bad']
            ascent_speed_bad = selectedVariables['ascent_speed_bad']
            cruise_speed_bad = selectedVariables['cruise_speed_bad']
            descent_speed_bad = selectedVariables['descent_speed_bad']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
